package bean;

public class Error {
}
